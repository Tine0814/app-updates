const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BFJtyeYN.js","./index-Cb8sYnCI.js","./index-CtgeJEzB.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-Cb8sYnCI.js";const _=r("Share",{web:()=>t(()=>import("./web-BFJtyeYN.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
