const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BKiIGP09.js","./index-CVXHK4HN.js","./index-CtgeJEzB.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-CVXHK4HN.js";const _=r("Share",{web:()=>t(()=>import("./web-BKiIGP09.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
