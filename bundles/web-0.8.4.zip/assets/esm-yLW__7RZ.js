const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BsfzfU2c.js","./index-DiGEqiKe.js","./index-DcCnpjRS.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-DiGEqiKe.js";const _=r("Share",{web:()=>t(()=>import("./web-BsfzfU2c.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
