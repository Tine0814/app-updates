const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C-oVmBl1.js","./index-CdmZpJCk.js","./index-Jfxq__-3.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-CdmZpJCk.js";const _=r("Share",{web:()=>t(()=>import("./web-C-oVmBl1.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
