const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-ByryjEih.js","./index-c88r3XwI.js","./index-BFxbpiJz.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-c88r3XwI.js";const _=r("Share",{web:()=>t(()=>import("./web-ByryjEih.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
