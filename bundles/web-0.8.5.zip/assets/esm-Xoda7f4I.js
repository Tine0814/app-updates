const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BH4fIm2T.js","./index-B7D78JrT.js","./index-DcCnpjRS.css"])))=>i.map(i=>d[i]);
import{m as r,_ as t}from"./index-B7D78JrT.js";const _=r("Share",{web:()=>t(()=>import("./web-BH4fIm2T.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
